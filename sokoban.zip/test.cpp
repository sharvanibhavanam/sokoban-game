// Copyright 2024 Sharvani Bhavanam

#include <fstream>
#define BOOST_TEST_DYN_LINK
#define BOOST_TEST_MODULE
#include <boost/test/unit_test.hpp>
#include "Sokoban.hpp"

using SB::Sokoban;
